Peppercorn
==========

A library for converting a token stream into a data structure comprised of
sequences, mappings, and scalars, developed primarily for converting HTTP form
post data into a richer data structure.  It runs on Python 2.6, 2.7, 3.2, and
3.3.

Please see http://docs.pylonsproject.org/projects/peppercorn/en/latest/
for the documentation.

See https://github.com/Pylons/peppercorn for in-development version.


Changes
=======

0.5 (2014-09-29)
----------------

- Switch to an iterative parser rather than a recursive parser to avoid
  DoS attacks.

- Add the ``ignore`` operation. The subsequent data elements in the stream
  will be ignored until the corresponding ``__end__`` marker.  This feature
  is useful for form elements designed for client-side scripting, such as a
  "select all" checkbox in the middle of a list of other kinds of fields.

- Add support for Python 3.3.

- Drop support for Python 2.5 / Jython.

0.4 (2012-02-14)
----------------

- Peppercorn will no longer run under Python 2.4.  2.5 or better is required.

- Python 3.2 compatibility.

- Moved to GitHub.

- Pylons project docs theme.

- Added tox configuration.

0.3 (2010-09-02)
----------------

- 0.2 was a brownbag release; a case was not handled where ``rename``
  operation types may not have children.  This release fixes that.

0.2 (2010-09-02)
----------------

- New operation type: ``rename``.  ``rename`` begins a special mode.
  The value of the first subsequent data element in the stream will be
  used within it's parent sequence or mapping; any remaining data
  elements until the corresponding ``__end__`` marker are ignored.
  This is mostly in support of radio buttons.  See the ``rename`` docs
  within `http://docs.repoze.org/peppercorn
  <http://docs.repoze.org/peppercorn>`_ for more information.

0.1 (2010-03-23)
----------------

- Initial release.


