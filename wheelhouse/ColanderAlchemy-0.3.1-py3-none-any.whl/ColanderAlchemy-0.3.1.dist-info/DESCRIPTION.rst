ColanderAlchemy
===============

`ColanderAlchemy` helps you to auto-generate `Colander
<http://docs.pylonsproject.org/projects/colander/en/latest/>`_ schemas
that are based on `SQLAlchemy <http://www.sqlalchemy.org/>`_ mapped classes.

Such `Colander` schemas can be used with libraries like `Deform
<http://docs.pylonsproject.org/projects/deform/>`_ and helps remove the 
need for duplication of schema definitions.


Documentation
-------------

Latest documentation is at: `Read The Docs
<http://readthedocs.org/docs/colanderalchemy/en/latest/index.html>`_.


Installation
------------

Using `pip` command::

    pip install ColanderAlchemy


License
-------

ColanderAlchemy is distributed under the `MIT license
<http://www.opensource.org/licenses/mit-license.php>`_.


Development version
-------------------

Fork the development version on
`GitHub <https://github.com/stefanofontanelli/ColanderAlchemy>`_.

The branch '0.1' contains the old version of ColanderAlchemy: 0.1x
The branch 'master' contains the new version of ColanderAlchemy: 0.3x

Support
-------

Please use `Github Issue System
<https://github.com/stefanofontanelli/ColanderAlchemy/issues/new>`_
for support requests (bug report, feature requests, other kind of help
requests).

`Follow me on Twitter @stefontanelli
<https://twitter.com/stefontanelli>`_
to receive notifications about new releases.


Change Log
==========

0.3.1 (2014-03-19)
----------------

- maintain the order of SQLAlchemy object attributes in the 
  Colander schema [tisdall]
- use Colander defaults wherever explicit settings are
  not given [tisdall]
- added tests for confirming documentation examples [tisdall]
- added fix and test for issue #35 (thrown exception on 
  encountering synonym() ) [tisdall]
- made changes to accommodate SQLAlchemy >= 0.9a [tisdall]
- allows "children" override (#44) [tisdall]
- no longer call callable SQLAlchemy defaults to fill in
  colander default values (#43) [tisdall]
- fixed some minor issues with colander default and missing values
  to ensure transitive relationships (such as dictify/objectify)
  [tisdall]
- require colander 1.0b1 or greater to support `colander.drop`
  (#52) [tisdall]

0.3 (2013-11-04)
----------------

- Add ``objectify`` function on ``SQLAlchemySchemaNode`` -- use this to
  recreate SQLAlchemy object instances from the configured mappers.
  This new method is the opposite of ``dictify``.
  [davidjb]
- Colander's ``DateTime`` now defaults to using a naive ``datetime``
  when no timezone is provided, similar to SQLAlchemy.
  [tisdall]
- fixed defaults for SchemaNode.default and SchemaNode.missing
  [tisdall]

0.2 (2013-05-16)
----------------

- No changes.

0.2a1 (2012-04-09)
------------------

- Ensure relationship mapped schemas have a ``name``. This ensures
  correct usage with ``Deform``.
- Ensure missing schema node information correctly maps to SQLAlchemy
  structures.
- Map missing information for "required" relationships based upon the
  join condition. This can be further customised by given relationships
  setting ``missing=colander.required`` within their respective
  configurations.
- Read Colander node init settings for a mapped class using the
  ``__colanderalchemy__`` attribute.  This allows for full customisation
  of the resulting ``colander.Mapping`` SchemaNode. 
- Allow non-SQLAlchemy schema nodes within ``SQLAlchemySchemaNode``.
  Previously, the ``dictify`` method would throw an ``AttributeError``.
- Fix setup.py for python 3k

0.1b7 (Unreleased)
------------------

- Ensure relationships are mapped recursively and adhere to
  ColanderAlchemy settings for mappings.
- Remove dictify method in SQLAlchemyMapping.

0.1b6 (2012-10-17)
------------------

- Fix minor bugs.

0.1b5 (2012-09-19)
------------------

- Fix bug in MappingRegistry.__init__:
  pkeys is a list of property keys instead of column name
- Add support to specify schema node ordering.

0.1b4 (2012-08-06)
------------------

- Fix bug related to 'ca_include=False'.
- Change tests to cover that bug.

0.1b3 (2012-08-02)
------------------

- Fix issue related to mapped class inheritance.
- Fix minor bugs.

0.1b2 (2012-06-14)
------------------

- Added support to use ColanderAlchemy declaratively.

0.1b (2012-05-19)
-----------------

- Added SQLAlchemyMapping.dictify method.
- Updated tests with checks needed to test SQLAlchemyMapping.dictify.

0.1.0a2 (unreleased)
--------------------

- Mentioned supported Python versions in trove classifiers.
- Updated tests to run with current `colander` versions.
- Made compatible with Python 3.2.

0.1.0a (2012-03-24)
-------------------

- Initial public release.


